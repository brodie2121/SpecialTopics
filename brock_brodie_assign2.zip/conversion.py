def feetToMeters(feet):
    return feet * 0.3048
def metersToFeet(meters):
    return meters / 0.3048
def displayTitle():
    print("Feet and Meters Converter")
    print()
def displayMenu():
    print("Conversion Menu:")
    print("a. Feet to Meters")
    print("b. Meters to Feet")